import secrets
from pydantic_settings import BaseSettings
from functools import lru_cache

# Sentinel value to detect when SECRET_KEY hasn't been set
_INSECURE_DEFAULT = "dev-secret-change-in-production"

class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite:///./dreamcoin.db"
    SECRET_KEY: str = _INSECURE_DEFAULT
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    FROM_EMAIL: str = "noreply@dreamcoin.casino"
    REDIS_URL: str = "redis://localhost:6379/0"
    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    ETH_RPC_URL: str = ""
    BTC_RPC_URL: str = ""
    USDT_CONTRACT: str = ""
    MAXMIND_LICENSE_KEY: str = ""
    RATE_LIMIT_REQUESTS_PER_MINUTE: int = 60
    RATE_LIMIT_AUTH_PER_MINUTE: int = 10
    MAX_FAILED_LOGIN_ATTEMPTS: int = 5
    ACCOUNT_LOCKOUT_MINUTES: int = 15
    ENVIRONMENT: str = "development"

    class Config:
        env_file = ".env"

@lru_cache()
def get_settings() -> Settings:
    settings = Settings()

    # CRITICAL: Refuse to start with the insecure default secret key
    # in any non-development environment
    if settings.SECRET_KEY == _INSECURE_DEFAULT:
        if settings.ENVIRONMENT != "development":
            raise RuntimeError(
                "FATAL: SECRET_KEY is set to the insecure default. "
                "Set a cryptographically random SECRET_KEY in your .env file. "
                "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
            )
        import warnings
        warnings.warn(
            "WARNING: Using insecure default SECRET_KEY. "
            "This is only acceptable in development. "
            "Set SECRET_KEY in .env before deploying.",
            stacklevel=2,
        )

    return settings
