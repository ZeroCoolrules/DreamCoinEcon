from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Numeric, JSON, ForeignKey, Enum
from sqlalchemy.orm import relationship
from app.db.session import Base
from datetime import datetime
import enum

class RoleEnum(str, enum.Enum):
    player = "player"
    admin = "admin"
    support = "support"

class AccountStatus(str, enum.Enum):
    active = "active"
    pending_kyc = "pending_kyc"
    restricted = "restricted"
    banned = "banned"
    self_excluded = "self_excluded"
    pending_email = "pending_email"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(Enum(RoleEnum), default=RoleEnum.player, nullable=False)
    account_status = Column(Enum(AccountStatus), default=AccountStatus.pending_email, nullable=False)

    legal_first_name = Column(String(100))
    legal_last_name = Column(String(100))
    date_of_birth = Column(DateTime)
    address_line1 = Column(String(255))
    address_line2 = Column(String(255))
    city = Column(String(100))
    state_province = Column(String(100))
    postal_code = Column(String(20))
    country = Column(String(2))
    phone = Column(String(50))

    email_verified = Column(Boolean, default=False)
    email_verified_at = Column(DateTime)
    mfa_enabled = Column(Boolean, default=False)
    mfa_secret = Column(String(255))

    kyc_status = Column(String(20), default="none")
    kyc_verified_at = Column(DateTime)
    age_verified = Column(Boolean, default=False)
    terms_accepted = Column(Boolean, default=False)
    terms_accepted_at = Column(DateTime)
    privacy_accepted = Column(Boolean, default=False)
    privacy_accepted_at = Column(DateTime)
    gambling_risk_acknowledged = Column(Boolean, default=False)
    gambling_risk_acknowledged_at = Column(DateTime)

    self_excluded_until = Column(DateTime)
    deposit_limit_daily = Column(Numeric(18, 8), default=0)
    deposit_limit_weekly = Column(Numeric(18, 8), default=0)
    deposit_limit_monthly = Column(Numeric(18, 8), default=0)
    wager_limit_daily = Column(Numeric(18, 8), default=0)
    loss_limit_daily = Column(Numeric(18, 8), default=0)
    session_limit_minutes = Column(Integer, default=0)
    cooling_off_until = Column(DateTime)

    last_login_at = Column(DateTime)
    last_login_ip = Column(String(45))
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)

    registration_ip = Column(String(45))
    allowed_countries = Column(JSON, default=list)
    blocked_countries = Column(JSON, default=list)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    wallet = relationship("Wallet", back_populates="user", uselist=False)
    sessions = relationship("UserSession", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user", foreign_keys="AuditLog.user_id")
    kyc_submissions = relationship("KYCSubmission", back_populates="user", foreign_keys="KYCSubmission.user_id")
    responsible_gaming_logs = relationship("ResponsibleGamingLog", back_populates="user")

class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_token = Column(String(255), unique=True, nullable=False)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    geo_country = Column(String(2))
    geo_city = Column(String(100))
    is_active = Column(Boolean, default=True)
    expired_at = Column(DateTime)
    revoked_at = Column(DateTime, nullable=True)          # H-2: session revocation timestamp
    revoke_reason = Column(String(100), nullable=True)    # H-2: why was session revoked
    created_at = Column(DateTime, default=datetime.utcnow)
    last_active_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="sessions")
