"""Security audit fixes — add columns for session revocation,
password reset tokens, MFA backup codes.

Revision ID: 001_security
Revises: None
Create Date: 2026-06-27
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "001_security"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # H-2: Session revocation columns
    op.add_column("user_sessions", sa.Column("revoked_at", sa.DateTime(), nullable=True))
    op.add_column("user_sessions", sa.Column("revoke_reason", sa.String(100), nullable=True))

    # M-1: Password reset token storage
    op.add_column("users", sa.Column("reset_token_hash", sa.String(64), nullable=True))
    op.add_column("users", sa.Column("reset_token_expires", sa.DateTime(), nullable=True))
    op.create_index("ix_users_reset_token_hash", "users", ["reset_token_hash"])

    # M-2: MFA backup code hashes
    op.add_column("users", sa.Column("mfa_backup_hashes", sa.JSON(), nullable=True))


def downgrade() -> None:
    op.drop_column("users", "mfa_backup_hashes")
    op.drop_index("ix_users_reset_token_hash", table_name="users")
    op.drop_column("users", "reset_token_expires")
    op.drop_column("users", "reset_token_hash")
    op.drop_column("user_sessions", "revoke_reason")
    op.drop_column("user_sessions", "revoked_at")
