from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from datetime import datetime
import logging

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.core.config import get_settings
from app.models.user import User
from app.models.kyc import KYCSubmission, KYCStatus
from app.schemas.kyc import KYCSubmitRequest, KYCStatusResponse
from app.utils.audit import log_action

router = APIRouter(prefix="/kyc", tags=["KYC"])
logger = logging.getLogger(__name__)
settings = get_settings()


@router.post("/submit")
def submit_kyc(data: KYCSubmitRequest, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if current_user.kyc_status == "approved":
        raise HTTPException(status_code=400, detail="KYC already approved")

    submission = KYCSubmission(
        user_id=current_user.id,
        status=KYCStatus.pending,
        id_document_url=data.id_document_url,
        proof_of_address_url=data.proof_of_address_url,
        selfie_url=data.selfie_url,
    )
    db.add(submission)
    current_user.kyc_status = "pending"
    db.commit()
    db.refresh(submission)

    log_action(db, "kyc_submitted", user_id=current_user.id, resource_type="kyc", resource_id=submission.id)
    return submission


@router.get("/status", response_model=KYCStatusResponse)
def kyc_status(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    submission = db.query(KYCSubmission).filter(
        KYCSubmission.user_id == current_user.id
    ).order_by(KYCSubmission.created_at.desc()).first()
    if not submission:
        return {"status": "none", "id_document_verified": False, "proof_of_address_verified": False, "selfie_verified": False}
    return submission


# ---------------------------------------------------------------------------
# H-4 FIX: KYC automation webhook
#
# Third-party KYC providers (Sumsub, Jumio, Onfido, etc.) send
# verification results via webhook. This endpoint processes their
# callback and auto-approves or auto-rejects based on the result.
#
# To integrate:
#   1. Sign up with a provider and configure their webhook URL to:
#      POST https://yourdomain.com/api/v1/kyc/webhook
#   2. Set KYC_WEBHOOK_SECRET in .env
#   3. The provider sends JSON with verification status
# ---------------------------------------------------------------------------

@router.post("/webhook")
async def kyc_webhook(request: Request, db: Session = Depends(get_db)):
    """
    H-4: Automated KYC verification webhook handler.

    Expected payload (adapt to your provider):
    {
        "submission_id": 123,
        "status": "approved" | "rejected" | "requires_action",
        "id_document_verified": true,
        "proof_of_address_verified": true,
        "selfie_verified": true,
        "risk_score": "low",
        "risk_flags": [],
        "provider_reference": "..."
    }
    """
    payload = await request.json()

    # Basic validation
    submission_id = payload.get("submission_id")
    status = payload.get("status")
    if not submission_id or not status:
        raise HTTPException(status_code=400, detail="Missing submission_id or status")

    submission = db.query(KYCSubmission).filter(KYCSubmission.id == int(submission_id)).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    # Update submission with provider results
    submission.verification_provider = payload.get("provider", "webhook")
    submission.verification_response = payload
    submission.risk_score = payload.get("risk_score", "unknown")
    submission.risk_flags = payload.get("risk_flags", [])
    submission.id_document_verified = payload.get("id_document_verified", False)
    submission.proof_of_address_verified = payload.get("proof_of_address_verified", False)
    submission.selfie_verified = payload.get("selfie_verified", False)

    # Map provider status to our KYC status
    if status == "approved":
        submission.status = KYCStatus.approved
        submission.user.kyc_status = "approved"
        submission.user.kyc_verified_at = datetime.utcnow()
        logger.info("KYC auto-approved for user %s (submission %s)", submission.user_id, submission.id)
    elif status == "rejected":
        submission.status = KYCStatus.rejected
        submission.user.kyc_status = "rejected"
        submission.rejection_reason = payload.get("rejection_reason", "Failed automated verification")
        logger.info("KYC auto-rejected for user %s (submission %s)", submission.user_id, submission.id)
    elif status == "requires_action":
        submission.status = KYCStatus.requires_action
        submission.user.kyc_status = "requires_action"
    else:
        submission.status = KYCStatus.in_review

    submission.reviewed_at = datetime.utcnow()
    db.commit()

    log_action(
        db, "kyc_webhook",
        user_id=submission.user_id,
        resource_type="kyc",
        resource_id=submission.id,
        details={"status": status, "risk_score": submission.risk_score},
    )

    return {"status": "processed", "kyc_status": submission.status.value}
