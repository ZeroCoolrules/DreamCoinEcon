from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime
from decimal import Decimal

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.wallet import Wallet, Transaction
from app.schemas.wallet import WalletResponse, TransactionResponse, DepositRequest, WithdrawRequest
from app.services.wallet_service import get_or_create_wallet, credit_balance, debit_balance, check_limits
from app.utils.audit import log_action
from app.utils.validators import get_client_ip
from app.services.aml_service import screen_transaction

router = APIRouter(prefix="/wallet", tags=["Wallet"])

@router.get("/", response_model=WalletResponse)
def get_wallet(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    wallet = get_or_create_wallet(db, current_user.id)
    return wallet

@router.get("/transactions", response_model=list[TransactionResponse])
def get_transactions(
    limit: int = 50,
    offset: int = 0,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    return db.query(Transaction).filter(Transaction.user_id == current_user.id).order_by(desc(Transaction.created_at)).offset(offset).limit(limit).all()

@router.post("/deposit")
def deposit(data: DepositRequest, request: Request, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    # Check idempotency
    existing = db.query(Transaction).filter(Transaction.external_id == data.idempotency_key).first()
    if existing:
        return {"transaction": existing.id, "status": existing.status}

    try:
        check_limits(db, current_user.id, data.amount)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))

    ip = get_client_ip(request)

    # H-3 FIX: AML screening before processing deposit
    aml_result = screen_transaction(db, current_user.id, data.amount, "deposit", ip)
    if aml_result.block_transaction:
        raise HTTPException(
            status_code=403,
            detail="Transaction held for compliance review. Our team will contact you.",
        )

    # Payment processor abstraction
    if data.method == "card":
        # In production: use Stripe/tokenized provider
        provider_status = "approved"
    elif data.method == "crypto":
        provider_status = "pending"
    else:
        provider_status = "pending"

    if provider_status == "approved":
        wallet, tx = credit_balance(
            db, current_user.id, data.amount, "cash", "deposit", data.method,
            reference_id=data.idempotency_key, description=f"Deposit via {data.method}", ip_address=ip
        )
        log_action(db, "deposit", user_id=current_user.id, resource_type="transaction", resource_id=tx.id, ip_address=ip)
        return {"transaction": tx.id, "status": "completed", "balance": float(wallet.cash_balance)}
    else:
        # Create pending transaction
        wallet = get_or_create_wallet(db, current_user.id)
        tx = Transaction(
            wallet_id=wallet.id, user_id=current_user.id, type="deposit", subtype=data.method,
            amount=data.amount, balance_before=wallet.cash_balance, balance_after=wallet.cash_balance,
            external_id=data.idempotency_key, status="pending", ip_address=ip
        )
        db.add(tx)
        db.commit()
        return {"transaction": tx.id, "status": "pending"}

@router.post("/withdraw")
def withdraw(data: WithdrawRequest, request: Request, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    # KYC check
    if current_user.kyc_status != "approved":
        raise HTTPException(status_code=403, detail="KYC verification required for withdrawals")

    # Check idempotency
    existing = db.query(Transaction).filter(Transaction.external_id == data.idempotency_key).first()
    if existing:
        return {"transaction": existing.id, "status": existing.status}

    try:
        check_limits(db, current_user.id, data.amount)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))

    wallet = get_or_create_wallet(db, current_user.id)
    if wallet.withdrawable_balance < data.amount:
        raise HTTPException(status_code=400, detail="Insufficient withdrawable balance")

    ip = get_client_ip(request)

    # H-3 FIX: AML screening before processing withdrawal
    aml_result = screen_transaction(db, current_user.id, data.amount, "withdrawal", ip)
    if aml_result.block_transaction:
        raise HTTPException(
            status_code=403,
            detail="Withdrawal held for compliance review. Our team will contact you.",
        )

    # For large withdrawals, require admin approval
    if data.amount > 1000:
        tx = Transaction(
            wallet_id=wallet.id, user_id=current_user.id, type="withdrawal", subtype=data.method,
            amount=-data.amount, balance_before=wallet.cash_balance, balance_after=wallet.cash_balance,
            external_id=data.idempotency_key, status="pending", description=f"Withdrawal request via {data.method}", ip_address=ip
        )
        db.add(tx)
        db.commit()
        log_action(db, "withdrawal_request", user_id=current_user.id, resource_type="transaction", resource_id=tx.id, ip_address=ip)
        return {"transaction": tx.id, "status": "pending_approval"}
    else:
        wallet, tx = debit_balance(
            db, current_user.id, data.amount, "cash", "withdrawal", data.method,
            reference_id=data.idempotency_key, description=f"Withdrawal via {data.method}", ip_address=ip
        )
        log_action(db, "withdrawal", user_id=current_user.id, resource_type="transaction", resource_id=tx.id, ip_address=ip)
        return {"transaction": tx.id, "status": "completed", "balance": float(wallet.cash_balance)}
