from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from decimal import Decimal
import secrets
import hashlib

from app.db.session import get_db
from app.core.config import get_settings
from app.core.security import (
    verify_password, get_password_hash, create_access_token, create_refresh_token,
    decode_token, generate_mfa_secret, verify_mfa_token, get_current_user,
    revoke_all_sessions,
)
from app.models.user import User, UserSession
from app.models.wallet import Wallet
from app.schemas.user import UserRegister, UserLogin, TokenResponse, MFASetupResponse, MFAEnableRequest
from app.services.email_service import send_verification_email, send_password_reset_email
from app.services.wallet_service import get_or_create_wallet
from app.utils.validators import validate_password, get_client_ip
from app.utils.audit import log_action
from app.middleware.rate_limit import rate_limit_auth, rate_limit_sensitive

router = APIRouter(prefix="/auth", tags=["Authentication"])

settings = get_settings()


# ---------------------------------------------------------------------------
# M-1 FIX: Store password-reset tokens as hashed values on the User row.
# In a larger system you'd use a dedicated table; this is the minimal fix.
# We add two columns to User: `reset_token_hash` and `reset_token_expires`.
# ---------------------------------------------------------------------------

def _hash_token(token: str) -> str:
    """One-way SHA-256 hash so we never store plaintext reset tokens."""
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------------------
# M-2 FIX: Hash and persist MFA backup codes on the User row.
# We add `mfa_backup_hashes` (JSON list) to User.
# ---------------------------------------------------------------------------


@router.post("/register", response_model=TokenResponse)
async def register(req: UserRegister, request: Request, db: Session = Depends(get_db)):
    # Rate limit: prevent mass account creation
    await rate_limit_auth(request)

    validate_password(req.password)

    if db.query(User).filter((User.email == req.email) | (User.username == req.username)).first():
        raise HTTPException(status_code=400, detail="Email or username already exists")

    # Age check (18+)
    age = (datetime.utcnow() - req.date_of_birth).days / 365.25
    if age < 18:
        raise HTTPException(status_code=400, detail="Must be 18 or older")

    ip = get_client_ip(request)

    user = User(
        email=req.email,
        username=req.username,
        hashed_password=get_password_hash(req.password),
        country=req.country,
        date_of_birth=req.date_of_birth,
        terms_accepted=req.terms_accepted,
        terms_accepted_at=datetime.utcnow(),
        privacy_accepted=req.privacy_accepted,
        privacy_accepted_at=datetime.utcnow(),
        gambling_risk_acknowledged=req.gambling_risk_acknowledged,
        gambling_risk_acknowledged_at=datetime.utcnow(),
        registration_ip=ip,
        account_status="pending_email",  # H-6: start as pending, not active
        age_verified=True,               # M-5: set after 18+ check above
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Create wallet
    get_or_create_wallet(db, user.id)

    # H-6 FIX: Generate and store email verification token
    token = secrets.token_urlsafe(32)
    user.reset_token_hash = _hash_token(token)        # reuse column for email verify
    user.reset_token_expires = datetime.utcnow() + timedelta(hours=24)
    db.commit()

    send_verification_email(user.email, token, user.username)

    log_action(db, "register", user_id=user.id, ip_address=ip, user_agent=request.headers.get("user-agent"))

    # Return tokens — but the user must verify email before playing
    session = UserSession(
        user_id=user.id,
        session_token=secrets.token_urlsafe(32),
        ip_address=ip,
        user_agent=request.headers.get("user-agent"),
    )
    db.add(session)
    db.commit()

    access_token = create_access_token({"sub": str(user.id), "session": session.session_token})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@router.post("/login", response_model=TokenResponse)
async def login(data: UserLogin, request: Request, db: Session = Depends(get_db)):
    # Rate limit: prevent brute-force attacks
    await rate_limit_auth(request)

    user = db.query(User).filter(
        (User.email == data.username_or_email) | (User.username == data.username_or_email)
    ).first()

    if not user or not verify_password(data.password, user.hashed_password):
        # Track failed login attempts for account lockout
        if user:
            user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
            if user.failed_login_attempts >= settings.MAX_FAILED_LOGIN_ATTEMPTS:
                user.locked_until = datetime.utcnow() + timedelta(
                    minutes=settings.ACCOUNT_LOCKOUT_MINUTES
                )
                log_action(
                    db, "account_locked",
                    user_id=user.id,
                    ip_address=get_client_ip(request),
                    details=f"Locked after {user.failed_login_attempts} failed attempts"
                )
            db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # H-6 FIX: Enforce email verification (configurable gate)
    if user.account_status == "pending_email":
        raise HTTPException(
            status_code=403,
            detail="Email verification required. Check your inbox or request a new link.",
        )

    if user.locked_until and user.locked_until > datetime.utcnow():
        remaining = (user.locked_until - datetime.utcnow()).seconds // 60
        raise HTTPException(
            status_code=403,
            detail=f"Account locked. Try again in {remaining + 1} minutes."
        )

    if user.account_status == "banned":
        raise HTTPException(status_code=403, detail="Account banned")

    if user.mfa_enabled:
        if not data.mfa_token or not verify_mfa_token(user.mfa_secret, data.mfa_token):
            return TokenResponse(access_token="", refresh_token="", mfa_required=True)

    ip = get_client_ip(request)
    user.last_login_at = datetime.utcnow()
    user.last_login_ip = ip
    user.failed_login_attempts = 0
    user.locked_until = None  # Clear any previous lockout on successful login

    session = UserSession(
        user_id=user.id,
        session_token=secrets.token_urlsafe(32),
        ip_address=ip,
        user_agent=request.headers.get("user-agent")
    )
    db.add(session)
    db.commit()

    log_action(db, "login", user_id=user.id, ip_address=ip)

    access_token = create_access_token({"sub": str(user.id), "session": session.session_token})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@router.post("/refresh")
def refresh(token: str, db: Session = Depends(get_db)):
    payload = decode_token(token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    user_id = int(payload["sub"])
    user = db.query(User).filter(User.id == user_id).first()
    if not user or user.account_status not in ("active", "pending_kyc"):
        raise HTTPException(status_code=401, detail="Invalid user")

    # Create a new session for the refreshed token
    session = UserSession(
        user_id=user.id,
        session_token=secrets.token_urlsafe(32),
        ip_address="refresh",
    )
    db.add(session)
    db.commit()

    return {"access_token": create_access_token({"sub": str(user.id), "session": session.session_token})}


@router.post("/logout")
def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # H-2: Revoke current session (not all — just this device)
    log_action(db, "logout", user_id=current_user.id)
    return {"message": "Logged out"}


@router.post("/mfa/setup", response_model=MFASetupResponse)
def setup_mfa(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    secret = generate_mfa_secret()
    import pyotp
    import qrcode
    import io
    import base64

    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=current_user.email, issuer_name="DreamCoin Casino")

    qr = qrcode.make(uri)
    buf = io.BytesIO()
    qr.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode()

    backup_codes = [secrets.token_hex(4) for _ in range(5)]

    # M-2 FIX: Hash and store backup codes so they survive restarts
    current_user.mfa_backup_hashes = [_hash_token(c) for c in backup_codes]
    db.commit()

    return MFASetupResponse(secret=secret, qr_uri=f"data:image/png;base64,{qr_b64}", backup_codes=backup_codes)


@router.post("/mfa/enable")
def enable_mfa(data: MFAEnableRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_mfa_token(data.secret, data.token):
        raise HTTPException(status_code=400, detail="Invalid MFA token")
    current_user.mfa_enabled = True
    current_user.mfa_secret = data.secret
    db.commit()
    return {"message": "MFA enabled"}


@router.post("/verify-email")
def verify_email_token(token: str, db: Session = Depends(get_db)):
    """
    H-6 FIX: Proper token-based email verification.
    The old version just picked the first pending_email user (!).
    """
    token_hash = _hash_token(token)
    user = db.query(User).filter(
        User.reset_token_hash == token_hash,
        User.account_status == "pending_email",
    ).first()

    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired verification link")

    if user.reset_token_expires and user.reset_token_expires < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Verification link has expired. Request a new one.")

    user.email_verified = True
    user.email_verified_at = datetime.utcnow()
    user.account_status = "active"
    user.reset_token_hash = None
    user.reset_token_expires = None
    db.commit()

    log_action(db, "email_verified", user_id=user.id)
    return {"message": "Email verified. You can now log in."}


@router.post("/resend-verification")
async def resend_verification(data: dict, request: Request, db: Session = Depends(get_db)):
    """H-6: Let users request a new verification email."""
    await rate_limit_sensitive(request)

    user = db.query(User).filter(
        User.email == data.get("email"),
        User.account_status == "pending_email",
    ).first()

    if user:
        token = secrets.token_urlsafe(32)
        user.reset_token_hash = _hash_token(token)
        user.reset_token_expires = datetime.utcnow() + timedelta(hours=24)
        db.commit()
        send_verification_email(user.email, token, user.username)

    # Always return success to prevent email enumeration
    return {"message": "If the email is pending verification, a new link has been sent."}


@router.post("/password-reset-request")
async def password_reset_request(data: dict, request: Request, db: Session = Depends(get_db)):
    """M-1 FIX: Store hashed token + expiry so it can be validated on redemption."""
    await rate_limit_sensitive(request)

    user = db.query(User).filter(User.email == data.get("email")).first()
    if user:
        token = secrets.token_urlsafe(32)
        user.reset_token_hash = _hash_token(token)
        user.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
        db.commit()
        send_password_reset_email(user.email, token)

    return {"message": "If the email exists, a reset link has been sent"}


@router.post("/password-reset")
async def password_reset(data: dict, request: Request, db: Session = Depends(get_db)):
    """
    M-1 FIX: Validate the stored hashed token, enforce expiry,
    then change the password and revoke all existing sessions.
    """
    await rate_limit_sensitive(request)

    token = data.get("token")
    new_password = data.get("new_password")
    if not token or not new_password:
        raise HTTPException(status_code=400, detail="token and new_password are required")

    validate_password(new_password)

    token_hash = _hash_token(token)
    user = db.query(User).filter(User.reset_token_hash == token_hash).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    if user.reset_token_expires and user.reset_token_expires < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Reset token has expired. Request a new one.")

    user.hashed_password = get_password_hash(new_password)
    user.reset_token_hash = None
    user.reset_token_expires = None

    # H-2: Force logout everywhere on password change
    revoked = revoke_all_sessions(db, user.id, reason="password_reset")
    db.commit()

    log_action(db, "password_reset", user_id=user.id, ip_address=get_client_ip(request))
    return {"message": f"Password reset successfully. {revoked} session(s) logged out."}
