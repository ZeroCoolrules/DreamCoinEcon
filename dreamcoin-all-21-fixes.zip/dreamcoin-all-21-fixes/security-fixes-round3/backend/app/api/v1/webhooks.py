from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.orm import Session
import json
import stripe

from app.db.session import get_db
from app.core.config import get_settings
from app.models.wallet import Transaction
from app.services.wallet_service import credit_balance, get_or_create_wallet
from app.utils.audit import log_action

router = APIRouter(prefix="/webhooks", tags=["Webhooks"])
settings = get_settings()


@router.post("/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    # ---- C-2 FIX: Always verify the Stripe webhook signature ----
    if not settings.STRIPE_WEBHOOK_SECRET:
        # Webhook secret not configured — reject in production, warn in dev
        if settings.ENVIRONMENT != "development":
            raise HTTPException(
                status_code=503,
                detail="Stripe webhook not configured. Set STRIPE_WEBHOOK_SECRET.",
            )
        # Dev fallback: parse raw JSON (no real money at risk)
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON payload")
    else:
        if not sig_header:
            raise HTTPException(status_code=400, detail="Missing stripe-signature header")
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
            )
        except stripe.error.SignatureVerificationError:
            log_action(db, "webhook_signature_invalid", details="Stripe signature mismatch")
            raise HTTPException(status_code=400, detail="Invalid signature")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid payload")

    event_type = event.get("type") if isinstance(event, dict) else event["type"]
    event_data = (
        event.get("data", {}).get("object", {})
        if isinstance(event, dict)
        else event["data"]["object"]
    )

    try:
        if event_type == "payment_intent.succeeded":
            _handle_payment_succeeded(db, event_data)
        elif event_type == "payment_intent.payment_failed":
            _handle_payment_failed(db, event_data)

        return {"status": "success"}
    except Exception as e:
        log_action(db, "webhook_processing_error", details=str(e))
        raise HTTPException(status_code=400, detail=str(e))


def _handle_payment_succeeded(db: Session, event_data: dict) -> None:
    tx_id = event_data.get("metadata", {}).get("transaction_id")
    if not tx_id:
        return

    tx = (
        db.query(Transaction)
        .filter(Transaction.id == int(tx_id), Transaction.status == "pending")
        .first()
    )
    if not tx:
        return

    wallet = get_or_create_wallet(db, tx.user_id)
    amount = tx.amount

    wallet.cash_balance += amount
    wallet.withdrawable_balance += amount
    wallet.total_deposited += amount

    tx.status = "completed"
    tx.balance_after = wallet.cash_balance
    tx.external_id = event_data.get("id")

    db.commit()
    log_action(
        db,
        "webhook_deposit_success",
        resource_type="transaction",
        resource_id=tx.id,
    )


def _handle_payment_failed(db: Session, event_data: dict) -> None:
    tx_id = event_data.get("metadata", {}).get("transaction_id")
    if not tx_id:
        return

    tx = db.query(Transaction).filter(Transaction.id == int(tx_id)).first()
    if tx:
        tx.status = "failed"
        db.commit()
        log_action(
            db,
            "webhook_deposit_failed",
            resource_type="transaction",
            resource_id=tx.id,
        )
