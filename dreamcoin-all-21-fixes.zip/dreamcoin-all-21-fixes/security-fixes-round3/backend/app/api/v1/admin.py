from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from datetime import datetime, timedelta
from decimal import Decimal

from app.db.session import get_db
from app.core.security import get_current_admin, revoke_all_sessions
from app.models.user import User
from app.models.wallet import Wallet, Transaction
from app.models.payment import Payment
from app.models.kyc import KYCSubmission
from app.models.game import GameRound, GameConfig
from app.models.compliance import AuditLog, AMLFlag
from app.schemas.admin import UserAdminResponse, BalanceAdjustRequest, AdminWithdrawalReview, GameConfigUpdate
from app.services.wallet_service import get_or_create_wallet, credit_balance, debit_balance
from app.utils.audit import log_action
from app.utils.validators import get_client_ip

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.get("/users")
def admin_users(
    q: str = None,
    status: str = None,
    kyc: str = None,
    limit: int = 50,
    offset: int = 0,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    query = db.query(User, Wallet).outerjoin(Wallet, User.id == Wallet.user_id)
    if q:
        query = query.filter((User.email.ilike(f"%{q}%")) | (User.username.ilike(f"%{q}%")))
    if status:
        query = query.filter(User.account_status == status)
    if kyc:
        query = query.filter(User.kyc_status == kyc)
    total = query.count()
    results = query.offset(offset).limit(limit).all()
    return {
        "total": total,
        "users": [
            {
                "id": u.id, "email": u.email, "username": u.username, "role": u.role.value,
                "account_status": u.account_status.value, "kyc_status": u.kyc_status,
                "cash_balance": float(w.cash_balance) if w else 0,
                "created_at": u.created_at.isoformat(), "last_login_at": u.last_login_at.isoformat() if u.last_login_at else None
            }
            for u, w in results
        ]
    }

@router.get("/users/{user_id}")
def admin_user_detail(user_id: int, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    wallet = get_or_create_wallet(db, user_id)
    kyc = db.query(KYCSubmission).filter(KYCSubmission.user_id == user_id).order_by(desc(KYCSubmission.created_at)).all()
    return {
        "user": {
            "id": user.id, "email": user.email, "username": user.username,
            "account_status": user.account_status.value, "kyc_status": user.kyc_status,
            "legal_name": f"{user.legal_first_name or ''} {user.legal_last_name or ''}".strip(),
            "country": user.country, "created_at": user.created_at.isoformat()
        },
        "wallet": {
            "cash_balance": float(wallet.cash_balance),
            "bonus_balance": float(wallet.bonus_balance),
            "locked_balance": float(wallet.locked_balance),
            "withdrawable_balance": float(wallet.withdrawable_balance)
        },
        "kyc": [{"id": k.id, "status": k.status.value, "created_at": k.created_at.isoformat()} for k in kyc]
    }

@router.post("/users/{user_id}/balance")
def admin_adjust_balance(
    user_id: int,
    data: BalanceAdjustRequest,
    request: Request,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    # Idempotency
    existing = db.query(Transaction).filter(Transaction.external_id == data.idempotency_key).first()
    if existing:
        return {"transaction": existing.id}

    if data.balance_type not in ["cash", "bonus", "locked"]:
        raise HTTPException(status_code=400, detail="Invalid balance type")

    if data.amount > 0:
        wallet, tx = credit_balance(
            db, user_id, data.amount, data.balance_type, "adjustment", "admin",
            external_id=data.idempotency_key, description=data.reason, ip_address=get_client_ip(request)
        )
    else:
        wallet, tx = debit_balance(
            db, user_id, abs(data.amount), data.balance_type, "adjustment", "admin",
            external_id=data.idempotency_key, description=data.reason, ip_address=get_client_ip(request)
        )

    log_action(
        db, "balance_adjust", admin_id=current_admin.id, user_id=user_id,
        resource_type="transaction", resource_id=tx.id,
        details={"amount": float(data.amount), "type": data.balance_type, "reason": data.reason}
    )
    return {"transaction": tx.id, "new_balance": float(getattr(wallet, f"{data.balance_type}_balance"))}

@router.post("/users/{user_id}/ban")
def admin_ban_user(user_id: int, reason: str, request: Request, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.account_status = "banned"
    revoked = revoke_all_sessions(db, user_id, reason="admin_ban")  # H-2: force logout
    db.commit()
    log_action(db, "ban", admin_id=current_admin.id, user_id=user_id, reason=reason, ip_address=get_client_ip(request))
    return {"message": f"User banned, {revoked} session(s) revoked"}

@router.post("/users/{user_id}/unban")
def admin_unban_user(user_id: int, request: Request, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.account_status = "active"
    db.commit()
    log_action(db, "unban", admin_id=current_admin.id, user_id=user_id, ip_address=get_client_ip(request))
    return {"message": "User unbanned"}

@router.get("/kyc")
def admin_kyc_list(
    status: str = "pending",
    limit: int = 50,
    offset: int = 0,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    q = db.query(KYCSubmission).filter(KYCSubmission.status == status)
    total = q.count()
    results = q.offset(offset).limit(limit).all()
    return {
        "total": total,
        "submissions": [
            {
                "id": k.id, "user_id": k.user_id, "user_email": k.user.email,
                "status": k.status.value, "created_at": k.created_at.isoformat()
            }
            for k in results
        ]
    }

@router.post("/kyc/{submission_id}/review")
def admin_kyc_review(submission_id: int, action: str, notes: str = None, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    submission = db.query(KYCSubmission).filter(KYCSubmission.id == submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    if action == "approve":
        submission.status = "approved"
        submission.user.kyc_status = "approved"
        submission.user.kyc_verified_at = datetime.utcnow()
    elif action == "reject":
        submission.status = "rejected"
        submission.rejection_reason = notes
        submission.user.kyc_status = "rejected"
    else:
        raise HTTPException(status_code=400, detail="Invalid action")

    submission.reviewed_by = current_admin.id
    submission.reviewed_at = datetime.utcnow()
    submission.review_notes = notes
    db.commit()
    return {"message": f"KYC {action}d"}

@router.get("/withdrawals")
def admin_withdrawals(
    status: str = "pending",
    limit: int = 50,
    offset: int = 0,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    q = db.query(Transaction).filter(Transaction.type == "withdrawal", Transaction.status == status)
    total = q.count()
    results = q.order_by(desc(Transaction.created_at)).offset(offset).limit(limit).all()
    return {
        "total": total,
        "withdrawals": [
            {
                "id": t.id, "user_id": t.user_id, "amount": float(t.amount),
                "status": t.status, "created_at": t.created_at.isoformat()
            }
            for t in results
        ]
    }

@router.post("/withdrawals/{withdrawal_id}/review")
def admin_withdrawal_review(withdrawal_id: int, data: AdminWithdrawalReview, request: Request, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    tx = db.query(Transaction).filter(Transaction.id == withdrawal_id).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")

    wallet = get_or_create_wallet(db, tx.user_id)

    if data.action == "approve":
        if tx.status != "pending":
            raise HTTPException(status_code=400, detail="Transaction not pending")
        # Deduct balance
        attr = "cash_balance" if tx.subtype != "bonus" else "bonus_balance"
        before = getattr(wallet, attr)
        amount = abs(tx.amount)
        if before < amount:
            raise HTTPException(status_code=400, detail="Insufficient user balance")
        after = before - amount
        setattr(wallet, attr, after)
        if attr == "cash_balance":
            wallet.withdrawable_balance -= amount
        tx.status = "completed"
        tx.balance_after = after
        tx.processed_at = datetime.utcnow()
    elif data.action == "reject":
        tx.status = "rejected"
    elif data.action == "hold":
        tx.status = "held"
    else:
        raise HTTPException(status_code=400, detail="Invalid action")

    db.commit()
    log_action(db, f"withdrawal_{data.action}", admin_id=current_admin.id, user_id=tx.user_id, resource_type="transaction", resource_id=tx.id, reason=data.notes)
    return {"message": f"Withdrawal {data.action}d"}

@router.get("/audit-logs")
def admin_audit_logs(
    user_id: int = None,
    action: str = None,
    limit: int = 100,
    offset: int = 0,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    q = db.query(AuditLog)
    if user_id:
        q = q.filter((AuditLog.user_id == user_id) | (AuditLog.admin_id == user_id))
    if action:
        q = q.filter(AuditLog.action == action)
    total = q.count()
    results = q.order_by(desc(AuditLog.created_at)).offset(offset).limit(limit).all()
    return {
        "total": total,
        "logs": [
            {
                "id": l.id, "user_id": l.user_id, "admin_id": l.admin_id,
                "action": l.action, "resource_type": l.resource_type,
                "resource_id": l.resource_id, "details": l.details,
                "reason": l.reason, "created_at": l.created_at.isoformat()
            }
            for l in results
        ]
    }

@router.get("/game-config/{game_type}")
def admin_game_config(game_type: str, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    config = db.query(GameConfig).filter(GameConfig.game_type == game_type).first()
    if not config:
        raise HTTPException(status_code=404, detail="Config not found")
    return {
        "game_type": config.game_type.value,
        "enabled": config.enabled,
        "min_bet": float(config.min_bet),
        "max_bet": float(config.max_bet),
        "max_payout": float(config.max_payout),
        "rtp": float(config.rtp),
        "house_edge": float(config.house_edge),
        "config": config.config
    }

@router.patch("/game-config/{game_type}")
def admin_update_game_config(game_type: str, data: GameConfigUpdate, request: Request, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    config = db.query(GameConfig).filter(GameConfig.game_type == game_type).first()
    if not config:
        config = GameConfig(game_type=game_type)
        db.add(config)

    update_data = data.dict(exclude_unset=True)
    for field, value in update_data.items():
        if field == "config":
            config.config = value
        else:
            setattr(config, field, value)

    config.updated_by = current_admin.id
    db.commit()

    log_action(db, "game_config_update", admin_id=current_admin.id, resource_type="game_config", resource_id=config.id, details=update_data, ip_address=get_client_ip(request))
    return {"message": "Config updated"}

@router.get("/stats")
def admin_stats(current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    total_users = db.query(func.count(User.id)).scalar()
    active_users = db.query(func.count(User.id)).filter(User.account_status == "active").scalar()
    pending_kyc = db.query(func.count(User.id)).filter(User.kyc_status == "pending").scalar()

    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_deposits = db.query(func.sum(Transaction.amount)).filter(
        Transaction.type == "deposit", Transaction.status == "completed", Transaction.created_at >= today
    ).scalar() or 0
    today_withdrawals = db.query(func.sum(Transaction.amount)).filter(
        Transaction.type == "withdrawal", Transaction.status == "completed", Transaction.created_at >= today
    ).scalar() or 0

    return {
        "total_users": total_users,
        "active_users": active_users,
        "pending_kyc": pending_kyc,
        "today_deposits": float(today_deposits),
        "today_withdrawals": float(today_withdrawals)
    }
