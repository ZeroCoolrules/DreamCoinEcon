from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from datetime import datetime
from decimal import Decimal
import hashlib
import secrets

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.game import GameRound, GameConfig
from app.models.wallet import Wallet
from app.schemas.game import (
    SlotsSpinRequest, SlotsSpinResponse,
    DiceRollRequest, DiceRollResponse,
    CrashPlaceBetRequest, CrashCashoutRequest,
    CrashRoundResponse, GameHistoryResponse
)
from app.services.wallet_service import get_or_create_wallet, place_bet, settle_bet
from app.services.provably_fair import generate_server_seed, hash_server_seed
from app.games.slots import evaluate_slots
from app.games.dice import evaluate_dice
from app.games.crash import CrashGame
from app.utils.audit import log_action
from app.utils.validators import validate_bet_amount, validate_client_seed, get_client_ip

router = APIRouter(prefix="/games", tags=["Games"])

# In-memory crash game instance (use Redis in production)
crash_game = CrashGame()

def get_game_config(db: Session, game_type: str) -> GameConfig:
    config = db.query(GameConfig).filter(GameConfig.game_type == game_type).first()
    if not config:
        config = GameConfig(game_type=game_type)
        db.add(config)
        db.commit()
    if not config.enabled:
        raise HTTPException(status_code=403, detail="Game currently disabled")
    return config

def create_round(db: Session, user_id: int, game_type: str, bet: Decimal, client_seed: str) -> GameRound:
    server_seed = generate_server_seed()
    round_obj = GameRound(
        user_id=user_id,
        game_type=game_type,
        server_seed=server_seed,
        server_seed_hash=hash_server_seed(server_seed),
        client_seed=client_seed,
        nonce=secrets.randbelow(1000000),
        bet_amount=bet,
        status="in_progress"
    )
    db.add(round_obj)
    db.commit()
    db.refresh(round_obj)
    return round_obj

@router.post("/slots/spin")
def slots_spin(data: SlotsSpinRequest, request: Request, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    config = get_game_config(db, "slots")
    validate_client_seed(data.client_seed)  # M-4
    validate_bet_amount(data.bet_amount, config.min_bet, config.max_bet, config.max_payout, Decimal("50"))

    wallet = get_or_create_wallet(db, current_user.id)
    if wallet.cash_balance + wallet.bonus_balance < data.bet_amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    ip = get_client_ip(request)
    round_obj = create_round(db, current_user.id, "slots", data.bet_amount, data.client_seed)

    # Deduct bet
    place_bet(db, current_user.id, data.bet_amount, "slots", round_obj.id, ip)

    # Evaluate
    grid, win_lines, payout = evaluate_slots(round_obj.server_seed, data.client_seed, round_obj.nonce, data.bet_amount)
    profit = payout - data.bet_amount

    round_obj.result = {
        "grid": grid,
        "win_lines": win_lines,
        "symbols": {i: s for i, s in enumerate(["7", "BAR", "BELL", "CHERRY", "LEMON", "GRAPE", "DIAMOND", "STAR"])}
    }
    round_obj.payout = payout
    round_obj.profit = profit
    round_obj.status = "completed"
    round_obj.completed_at = datetime.utcnow()
    db.commit()

    if payout > 0:
        settle_bet(db, current_user.id, payout, "slots", round_obj.id, ip)

    log_action(db, "game_spin", user_id=current_user.id, resource_type="game_round", resource_id=round_obj.id, details={"game": "slots", "bet": float(data.bet_amount), "payout": float(payout)})

    return SlotsSpinResponse(
        round_id=round_obj.id,
        grid=grid,
        win_lines=win_lines,
        payout=payout,
        profit=profit,
        server_seed_hash=round_obj.server_seed_hash,
        nonce=round_obj.nonce
    )

@router.post("/dice/roll")
def dice_roll(data: DiceRollRequest, request: Request, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    config = get_game_config(db, "dice")
    validate_client_seed(data.client_seed)  # M-4
    win_chance = 100 - data.target if data.is_over else data.target - 1
    multiplier = (Decimal("99") / Decimal(win_chance)).quantize(Decimal("0.0001")) if win_chance > 0 else Decimal("0")
    validate_bet_amount(data.bet_amount, config.min_bet, config.max_bet, config.max_payout, multiplier)

    wallet = get_or_create_wallet(db, current_user.id)
    if wallet.cash_balance + wallet.bonus_balance < data.bet_amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    ip = get_client_ip(request)
    round_obj = create_round(db, current_user.id, "dice", data.bet_amount, data.client_seed)

    place_bet(db, current_user.id, data.bet_amount, "dice", round_obj.id, ip)

    roll, win, payout, profit, multiplier = evaluate_dice(round_obj.server_seed, data.client_seed, round_obj.nonce, data.target, data.is_over, data.bet_amount)

    round_obj.result = {"roll": roll, "target": data.target, "is_over": data.is_over, "win": win}
    round_obj.payout = payout
    round_obj.profit = profit
    round_obj.status = "completed"
    round_obj.completed_at = datetime.utcnow()
    db.commit()

    if payout > 0:
        settle_bet(db, current_user.id, payout, "dice", round_obj.id, ip)

    log_action(db, "game_roll", user_id=current_user.id, resource_type="game_round", resource_id=round_obj.id, details={"game": "dice", "bet": float(data.bet_amount), "payout": float(payout)})

    return DiceRollResponse(
        round_id=round_obj.id,
        roll=roll,
        target=data.target,
        is_over=data.is_over,
        win=win,
        payout=payout,
        profit=profit,
        multiplier=multiplier,
        server_seed_hash=round_obj.server_seed_hash,
        nonce=round_obj.nonce
    )

import asyncio
from fastapi import WebSocket, WebSocketDisconnect
from app.games.multiplayer_crash import manager, crash_instance

@router.websocket("/crash/ws/{user_id}")
async def crash_websocket(websocket: WebSocket, user_id: int):
    await manager.connect(websocket, user_id)
    try:
        # Send current state
        await websocket.send_json({
            "type": "init",
            "status": crash_instance.status,
            "multiplier": crash_instance.multiplier,
            "countdown": crash_instance.countdown,
            "bets": crash_instance.bets
        })
        while True:
            data = await websocket.receive_text()
            # Handle incoming WS messages (e.g., place bet, cashout) if needed, 
            # though REST endpoints are cleaner for transactions
    except WebSocketDisconnect:
        manager.disconnect(user_id)

# And expose a simpler real-time crash logic that uses the multiplayer state
@router.post("/crash/place-bet")
def crash_place_bet(data: CrashPlaceBetRequest, request: Request, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    config = get_game_config(db, "crash")
    validate_client_seed(data.client_seed)  # M-4
    validate_bet_amount(data.bet_amount, config.min_bet, config.max_bet, config.max_payout, Decimal("1000"))

    wallet = get_or_create_wallet(db, current_user.id)
    if wallet.cash_balance + wallet.bonus_balance < data.bet_amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    # Deduct bet
    ip = get_client_ip(request)
    round_obj = create_round(db, current_user.id, "crash", data.bet_amount, data.client_seed)
    place_bet(db, current_user.id, data.bet_amount, "crash", round_obj.id, ip)

    # Start in-memory crash round (server-managed, provably fair)
    crash_game.start_round(
        round_obj.id,
        round_obj.server_seed,
        data.client_seed,
        round_obj.nonce,
        config.house_edge
    )

    round_obj.status = "in_progress"
    db.commit()

    return {
        "round_id": round_obj.id,
        "server_seed_hash": round_obj.server_seed_hash,
        "nonce": round_obj.nonce,
        "start_time": datetime.utcnow().isoformat(),
        "bet_placed": True
    }


@router.get("/crash/round/{round_id}")
def crash_round_status(
    round_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    round_obj = db.query(GameRound).filter(
        GameRound.id == round_id,
        GameRound.user_id == current_user.id,
        GameRound.game_type == "crash"
    ).first()
    if not round_obj:
        raise HTTPException(status_code=404, detail="Round not found")

    if round_obj.status != "in_progress":
        return {
            "round_id": round_obj.id,
            "status": round_obj.status,
            "result": round_obj.result,
            "payout": float(round_obj.payout) if round_obj.payout else 0,
            "profit": float(round_obj.profit) if round_obj.profit else 0
        }

    status = crash_game.get_status(round_id)
    if not status:
        # Round lost from memory (server restart) — auto-resolve as crashed
        round_obj.status = "completed"
        round_obj.result = {"status": "crashed", "reason": "round_expired"}
        round_obj.completed_at = datetime.utcnow()
        db.commit()
        return {
            "round_id": round_obj.id,
            "status": "crashed",
            "current_multiplier": 1.0,
            "payout": 0,
            "profit": -float(round_obj.bet_amount)
        }

    if status["crashed"]:
        round_obj.status = "completed"
        round_obj.result = {"crash_point": status["crash_point"], "status": "crashed"}
        round_obj.payout = Decimal("0")
        round_obj.profit = -round_obj.bet_amount
        round_obj.completed_at = datetime.utcnow()
        db.commit()
        log_action(db, "game_crash", user_id=current_user.id, resource_type="game_round", resource_id=round_obj.id,
                   details={"game": "crash", "bet": float(round_obj.bet_amount), "crash_point": status["crash_point"]})

    return {
        "round_id": round_obj.id,
        "status": "crashed" if status["crashed"] else "in_progress",
        "current_multiplier": status["current_multiplier"],
        "crash_point": status["crash_point"] if status["crashed"] else None,
        "elapsed": status["elapsed"]
    }


@router.post("/crash/cashout/{round_id}")
def crash_cashout(
    round_id: int,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    round_obj = db.query(GameRound).filter(
        GameRound.id == round_id,
        GameRound.user_id == current_user.id,
        GameRound.game_type == "crash"
    ).first()
    if not round_obj:
        raise HTTPException(status_code=404, detail="Round not found")
    if round_obj.status != "in_progress":
        raise HTTPException(status_code=400, detail="Round already completed")

    cashout_multiplier = crash_game.cashout(round_id)
    if cashout_multiplier is None:
        # Already crashed
        round_obj.status = "completed"
        round_obj.result = {"status": "crashed"}
        round_obj.payout = Decimal("0")
        round_obj.profit = -round_obj.bet_amount
        round_obj.completed_at = datetime.utcnow()
        db.commit()
        raise HTTPException(status_code=400, detail="Already crashed")

    payout = round_obj.bet_amount * cashout_multiplier
    profit = payout - round_obj.bet_amount

    ip = get_client_ip(request)
    settle_bet(db, current_user.id, payout, "crash", round_obj.id, ip)

    round_obj.status = "completed"
    round_obj.result = {
        "cashout_multiplier": float(cashout_multiplier),
        "status": "cashed_out"
    }
    round_obj.payout = payout
    round_obj.profit = profit
    round_obj.completed_at = datetime.utcnow()
    db.commit()

    log_action(db, "game_cashout", user_id=current_user.id, resource_type="game_round", resource_id=round_obj.id,
               details={"game": "crash", "bet": float(round_obj.bet_amount), "cashout_multiplier": float(cashout_multiplier), "payout": float(payout)})

    return {
        "round_id": round_obj.id,
        "cashout_multiplier": float(cashout_multiplier),
        "payout": float(payout),
        "profit": float(profit),
        "status": "cashed_out",
        "server_seed_hash": round_obj.server_seed_hash,
        "nonce": round_obj.nonce
    }


@router.get("/history")
def game_history(
    game_type: str = None,
    limit: int = 50,
    offset: int = 0,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    q = db.query(GameRound).filter(GameRound.user_id == current_user.id)
    if game_type:
        q = q.filter(GameRound.game_type == game_type)
    rounds = q.order_by(GameRound.created_at.desc()).offset(offset).limit(limit).all()

    # L-3 FIX: Only reveal server_seed for completed rounds.
    # For in-progress rounds, show only the hash so the player
    # can't predict outcomes.
    return [
        {
            "id": r.id,
            "game_type": r.game_type.value if hasattr(r.game_type, "value") else r.game_type,
            "bet_amount": float(r.bet_amount),
            "payout": float(r.payout) if r.payout else 0,
            "profit": float(r.profit) if r.profit else 0,
            "status": r.status,
            "server_seed_hash": r.server_seed_hash,
            "server_seed": r.server_seed if r.status == "completed" else None,
            "client_seed": r.client_seed,
            "nonce": r.nonce,
            "result": r.result,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "completed_at": r.completed_at.isoformat() if r.completed_at else None,
        }
        for r in rounds
    ]
