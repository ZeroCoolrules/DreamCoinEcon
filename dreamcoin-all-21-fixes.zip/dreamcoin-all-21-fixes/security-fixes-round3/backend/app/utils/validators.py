from fastapi import HTTPException, Request
from pydantic import BaseModel
from decimal import Decimal
import re


def validate_client_seed(client_seed: str) -> None:
    """
    M-4 FIX: Validate client_seed input to prevent injection or
    excessively long seeds that could waste memory/CPU.

    Rules:
    - Must be a non-empty string
    - Max 64 characters
    - Only alphanumeric + hyphen + underscore allowed
    """
    if not client_seed or not isinstance(client_seed, str):
        raise HTTPException(status_code=400, detail="client_seed is required")
    if len(client_seed) > 64:
        raise HTTPException(status_code=400, detail="client_seed must be 64 characters or fewer")
    if not re.match(r"^[a-zA-Z0-9_-]+$", client_seed):
        raise HTTPException(
            status_code=400,
            detail="client_seed must contain only letters, numbers, hyphens, and underscores",
        )


def validate_password(password: str) -> None:
    if len(password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    if not re.search(r"[A-Z]", password):
        raise HTTPException(status_code=400, detail="Password must contain an uppercase letter")
    if not re.search(r"[a-z]", password):
        raise HTTPException(status_code=400, detail="Password must contain a lowercase letter")
    if not re.search(r"[0-9]", password):
        raise HTTPException(status_code=400, detail="Password must contain a digit")

def validate_bet_amount(amount: Decimal, min_bet: Decimal, max_bet: Decimal, max_payout: Decimal, multiplier: Decimal = Decimal("1")) -> None:
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Bet amount must be positive")
    if amount < min_bet:
        raise HTTPException(status_code=400, detail=f"Minimum bet is {min_bet}")
    if amount > max_bet:
        raise HTTPException(status_code=400, detail=f"Maximum bet is {max_bet}")
    if amount * multiplier > max_payout:
        raise HTTPException(status_code=400, detail=f"Maximum payout is {max_payout}")

def get_client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
