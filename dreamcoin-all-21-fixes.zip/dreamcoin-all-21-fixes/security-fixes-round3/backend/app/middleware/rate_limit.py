"""
In-memory rate limiter for auth endpoints.

Uses a simple sliding-window counter per IP address. For production with
multiple workers/processes, swap the _store dict for Redis using the
REDIS_URL already in Settings (e.g. via `redis.asyncio`).

Endpoints import `rate_limit_auth` and `rate_limit_sensitive` and call
them at the top of their handler.  On excess, a 429 is raised.
"""

from collections import defaultdict
from datetime import datetime, timedelta
from fastapi import HTTPException, Request, status
from app.utils.validators import get_client_ip
from app.core.config import get_settings

settings = get_settings()

# {ip: [(timestamp, ...),]}
_store: dict[str, list[datetime]] = defaultdict(list)


def _clean(ip: str, window: timedelta) -> None:
    """Remove timestamps older than the window."""
    cutoff = datetime.utcnow() - window
    _store[ip] = [ts for ts in _store[ip] if ts > cutoff]


async def _check_rate(request: Request, max_requests: int, window_seconds: int, label: str) -> None:
    """Core rate-check logic shared by the public helpers."""
    ip = get_client_ip(request)
    window = timedelta(seconds=window_seconds)
    _clean(ip, window)

    if len(_store[ip]) >= max_requests:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many {label} attempts. Try again in {window_seconds // 60} minute(s).",
            headers={"Retry-After": str(window_seconds)},
        )

    _store[ip].append(datetime.utcnow())


async def rate_limit_auth(request: Request) -> None:
    """Rate limit for login / register — 10 req/min per IP (configurable)."""
    await _check_rate(
        request,
        max_requests=settings.RATE_LIMIT_AUTH_PER_MINUTE,
        window_seconds=60,
        label="authentication",
    )


async def rate_limit_sensitive(request: Request) -> None:
    """Stricter limit for password-reset / email-based flows — 3 req/min."""
    await _check_rate(
        request,
        max_requests=3,
        window_seconds=60,
        label="request",
    )
