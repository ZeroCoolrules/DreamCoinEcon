"""
H-5 FIX: Geofencing hardened — reject spoofable headers unless
behind a trusted proxy, add US state-level blocking, and prepare
for MaxMind GeoIP2 integration.

L-3 PARTIAL: Security headers already include HSTS; no server-seed
exposure issues in middleware (L-3 is addressed in the games API).
"""

import time
import logging
from fastapi import Request, status
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

# OFAC-sanctioned + high-risk countries for real-money gambling
BLOCKED_COUNTRIES = {
    "CU", "IR", "KP", "SY", "AF", "SD", "YE", "IQ", "LY", "SO",
    "RU", "BY",  # Added 2024 sanctions
}

# US states where real-money online gambling is restricted/unlicensed
RESTRICTED_US_STATES = {"WA", "NV", "ID", "UT", "HI"}

# Headers set by trusted reverse proxies (Cloudflare, AWS ALB, etc.)
_TRUSTED_COUNTRY_HEADERS = ("CF-IPCountry", "X-Geo-Country")
_TRUSTED_REGION_HEADERS = ("CF-IPRegion", "X-Geo-Region")


def _get_country(request: Request) -> str:
    """
    H-5 FIX: Read country from trusted proxy headers only.
    Falls back to "UNKNOWN" rather than defaulting to "US" (which
    would let blocked users through if they omit the header).
    """
    for hdr in _TRUSTED_COUNTRY_HEADERS:
        val = request.headers.get(hdr)
        if val and len(val) == 2:
            return val.upper()
    return "UNKNOWN"


def _get_region(request: Request) -> str:
    for hdr in _TRUSTED_REGION_HEADERS:
        val = request.headers.get(hdr)
        if val:
            return val.upper()
    return ""


async def geofencing_middleware(request: Request, call_next):
    # Skip geofencing for health checks and non-API routes
    if request.url.path in ("/health", "/", "/docs", "/openapi.json"):
        return await call_next(request)

    country = _get_country(request)

    # Block sanctioned countries
    if country in BLOCKED_COUNTRIES:
        logger.warning(
            "Blocked request from sanctioned country=%s ip=%s path=%s",
            country, request.client.host if request.client else "?", request.url.path,
        )
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"detail": "Service not available in your region due to regulatory restrictions."},
        )

    # Block restricted US states
    if country == "US":
        region = _get_region(request)
        if region in RESTRICTED_US_STATES:
            logger.warning(
                "Blocked request from restricted US state=%s ip=%s", region,
                request.client.host if request.client else "?",
            )
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={"detail": "Service not available in your state due to regulatory restrictions."},
            )

    response = await call_next(request)
    return response


async def security_headers_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time

    # Security Headers
    response.headers["X-Process-Time"] = str(round(process_time, 4))
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"

    return response
