from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from contextlib import asynccontextmanager
import time
import warnings

from app.db.session import engine, Base
from app.db.init_db import init_db
from app.core.config import get_settings
from app.api.v1 import auth, users, wallet, games, kyc, admin, webhooks

import asyncio
from app.games.multiplayer_crash import crash_instance

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # L-2 WARNING: Alert if SQLite is used outside development
    if settings.DATABASE_URL.startswith("sqlite") and settings.ENVIRONMENT != "development":
        warnings.warn(
            "WARNING: SQLite detected in non-development environment. "
            "Use PostgreSQL for production: set DATABASE_URL in .env.",
            stacklevel=2,
        )

    init_db()
    # Start the crash game loop in background
    asyncio.create_task(crash_instance.game_loop())
    yield


from app.middleware.security import geofencing_middleware, security_headers_middleware

app = FastAPI(
    title="DreamCoin Casino API",
    description="Licensed-ready real-money online casino platform",
    version="1.0.0",
    lifespan=lifespan
)


# L-4 FIX: HTTPS redirect middleware for production
async def https_redirect_middleware(request: Request, call_next):
    if settings.FORCE_HTTPS:
        # Check X-Forwarded-Proto (set by reverse proxies like nginx, Cloudflare)
        proto = request.headers.get("x-forwarded-proto", "https")
        if proto == "http" and request.url.path != "/health":
            url = request.url.replace(scheme="https")
            return RedirectResponse(url=str(url), status_code=301)
    return await call_next(request)


# Security middleware
app.middleware("http")(https_redirect_middleware)
app.middleware("http")(geofencing_middleware)
app.middleware("http")(security_headers_middleware)

# L-1 FIX: CORS origins from config (env-overridable)
cors_origins = [o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(wallet.router, prefix="/api/v1")
app.include_router(games.router, prefix="/api/v1")
app.include_router(kyc.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")
app.include_router(webhooks.router, prefix="/api/v1")

@app.get("/health")
def health_check():
    return {"status": "ok", "service": "dreamcoin-casino"}

@app.get("/")
def root():
    return {"message": "DreamCoin Casino API", "version": "1.0.0"}
