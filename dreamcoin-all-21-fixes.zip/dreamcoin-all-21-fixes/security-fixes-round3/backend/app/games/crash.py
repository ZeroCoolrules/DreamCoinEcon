"""
H-1 FIX: Crash game engine with DB-backed state.

The original CrashGame stored all round state in a plain dict —
a server restart wiped every active round, letting players lose
their bets with no recourse.

This version still calculates crash points and multipliers in
memory for speed, but the authoritative state lives in the
GameRound database row. If the in-memory cache is empty (e.g.
after a restart), the API layer gracefully resolves the round
from the DB.
"""

import math
from datetime import datetime
from decimal import Decimal
from typing import Dict, Any, Optional
from app.services.provably_fair import crash_point


class CrashGame:
    def __init__(self):
        # Lightweight in-memory cache for timing only.
        # Keys are round_id → timing/crash data.
        # This is a *cache*, not the source of truth.
        self._cache: Dict[int, Dict[str, Any]] = {}

    def start_round(
        self,
        round_id: int,
        server_seed: str,
        client_seed: str,
        nonce: int,
        house_edge: Decimal = Decimal("0.01"),
    ) -> Dict[str, Any]:
        point = crash_point(server_seed, client_seed, nonce, house_edge)
        now = datetime.utcnow()
        entry = {
            "round_id": round_id,
            "crash_point": point,
            "status": "active",
            "start_time": now,
        }
        self._cache[round_id] = entry

        # Evict old entries to prevent unbounded growth
        if len(self._cache) > 200:
            oldest_keys = sorted(
                self._cache, key=lambda k: self._cache[k]["start_time"]
            )[: len(self._cache) - 200]
            for k in oldest_keys:
                del self._cache[k]

        return entry

    def get_status(self, round_id: int) -> Optional[Dict[str, Any]]:
        info = self._cache.get(round_id)
        if not info:
            return None  # Round not in cache — caller should resolve from DB
        elapsed = (datetime.utcnow() - info["start_time"]).total_seconds()
        # Exponential curve: m = e^(0.1 * t)
        current_multiplier = math.exp(0.1 * elapsed)
        crashed = current_multiplier >= float(info["crash_point"])
        return {
            "elapsed": elapsed,
            "current_multiplier": round(current_multiplier, 2),
            "crash_point": float(info["crash_point"]),
            "crashed": crashed,
            "status": "crashed" if crashed else "active",
        }

    def cashout(self, round_id: int) -> Optional[Decimal]:
        info = self._cache.get(round_id)
        if not info or info.get("status") != "active":
            return None
        status = self.get_status(round_id)
        if not status or status["crashed"]:
            info["status"] = "crashed"
            return None
        info["status"] = "cashed_out"
        return Decimal(str(status["current_multiplier"]))

    def end_round(self, round_id: int) -> Optional[Dict[str, Any]]:
        info = self._cache.get(round_id)
        if not info:
            return None
        info["status"] = "crashed"
        result = {
            "crash_point": float(info["crash_point"]),
            "status": "crashed",
        }
        # Remove from cache — the DB row is the permanent record
        self._cache.pop(round_id, None)
        return result

    def remove(self, round_id: int) -> None:
        """Remove a round from the in-memory cache after DB settlement."""
        self._cache.pop(round_id, None)
