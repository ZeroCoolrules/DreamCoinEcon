"""
M-6 FIX: Use a unique random client_seed per round (was hardcoded "global_client_seed").
M-7 FIX: Exponential multiplier curve (was linear += 0.05).
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List
import json
import asyncio
import math
from decimal import Decimal
from datetime import datetime
import secrets


class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[int, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    def disconnect(self, user_id: int):
        self.active_connections.pop(user_id, None)

    async def broadcast(self, message: dict):
        disconnected = []
        for uid, conn in self.active_connections.items():
            try:
                await conn.send_json(message)
            except Exception:
                disconnected.append(uid)
        for uid in disconnected:
            self.active_connections.pop(uid, None)


manager = ConnectionManager()


class MultiplayerCrash:
    def __init__(self):
        self.status = "waiting"  # waiting, betting, in_progress, crashed
        self.multiplier = 1.00
        self.crash_point = 1.00
        self.bets = {}
        self.countdown = 5.0
        self._start_time: float = 0.0  # monotonic reference for curve

    def reset(self):
        self.status = "waiting"
        self.multiplier = 1.00
        self.bets = {}
        self.countdown = 5.0

    async def game_loop(self):
        while True:
            if self.status == "waiting":
                self.reset()
                self.status = "betting"
                await manager.broadcast({
                    "type": "status",
                    "status": self.status,
                    "countdown": self.countdown,
                })

                # Betting phase countdown
                while self.countdown > 0:
                    await asyncio.sleep(1)
                    self.countdown -= 1
                    await manager.broadcast({
                        "type": "countdown",
                        "countdown": self.countdown,
                    })

                # Start round — M-6 FIX: unique client_seed per round
                from app.services.provably_fair import crash_point as calc_crash, generate_server_seed

                server_seed = generate_server_seed()
                client_seed = secrets.token_hex(16)  # was "global_client_seed"
                nonce = secrets.randbelow(1_000_000)
                self.crash_point = float(
                    calc_crash(server_seed, client_seed, nonce)
                )

                self.status = "in_progress"
                self._start_time = asyncio.get_event_loop().time()
                await manager.broadcast({"type": "status", "status": self.status})

            elif self.status == "in_progress":
                await asyncio.sleep(0.1)

                # M-7 FIX: exponential curve instead of linear += 0.05
                elapsed = asyncio.get_event_loop().time() - self._start_time
                self.multiplier = round(math.exp(0.1 * elapsed), 2)

                if self.multiplier >= self.crash_point:
                    self.status = "crashed"
                    self.multiplier = self.crash_point
                    await manager.broadcast({
                        "type": "crash",
                        "multiplier": self.multiplier,
                    })

                    # Settle crashed bets
                    for user_id, bet in self.bets.items():
                        if bet["status"] == "active":
                            bet["status"] = "crashed"

                    await asyncio.sleep(4)  # Show crash screen for 4s
                    self.status = "waiting"
                else:
                    await manager.broadcast({
                        "type": "tick",
                        "multiplier": self.multiplier,
                    })


crash_instance = MultiplayerCrash()
