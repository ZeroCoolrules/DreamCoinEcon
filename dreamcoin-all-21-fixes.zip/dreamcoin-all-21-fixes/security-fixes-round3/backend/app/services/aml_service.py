"""
H-3 FIX: AML (Anti-Money Laundering) screening service.

Implements rule-based transaction monitoring that flags suspicious
activity for manual review. In production, integrate with a
third-party AML provider (e.g., Sumsub, Jumio, ComplyAdvantage).

Current rules:
1. Single transaction > $3,000 (CTR-adjacent threshold)
2. Cumulative deposits in 24h > $5,000
3. Rapid deposit-then-withdraw pattern (structuring indicator)
4. Multiple small deposits within 1 hour (smurfing)
"""

from decimal import Decimal
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List, Dict
import logging

from app.models.wallet import Transaction
from app.models.compliance import AMLFlag
from app.utils.audit import log_action

logger = logging.getLogger(__name__)

# Thresholds (could be moved to config/env)
SINGLE_TX_THRESHOLD = Decimal("3000")
DAILY_CUMULATIVE_THRESHOLD = Decimal("5000")
RAPID_WITHDRAW_WINDOW_MINUTES = 30
SMURFING_COUNT_THRESHOLD = 5  # 5+ deposits in 1 hour
SMURFING_WINDOW_MINUTES = 60


class AMLScreeningResult:
    def __init__(self):
        self.flagged: bool = False
        self.flags: List[str] = []
        self.risk_level: str = "low"  # low, medium, high
        self.block_transaction: bool = False

    def add_flag(self, flag: str, risk: str = "medium"):
        self.flagged = True
        self.flags.append(flag)
        # Escalate risk level
        risk_order = {"low": 0, "medium": 1, "high": 2}
        if risk_order.get(risk, 0) > risk_order.get(self.risk_level, 0):
            self.risk_level = risk

    def __repr__(self):
        return f"AMLResult(flagged={self.flagged}, risk={self.risk_level}, flags={self.flags})"


def screen_transaction(
    db: Session,
    user_id: int,
    amount: Decimal,
    tx_type: str,  # "deposit" or "withdrawal"
    ip_address: Optional[str] = None,
) -> AMLScreeningResult:
    """
    Run AML checks against a proposed transaction.
    Returns an AMLScreeningResult; the caller decides whether to
    proceed, hold, or block.
    """
    result = AMLScreeningResult()
    now = datetime.utcnow()

    # Rule 1: Large single transaction
    if amount >= SINGLE_TX_THRESHOLD:
        result.add_flag(
            f"Large {tx_type}: ${amount} exceeds ${SINGLE_TX_THRESHOLD} threshold",
            risk="medium",
        )

    # Rule 2: Cumulative daily deposits
    if tx_type == "deposit":
        day_ago = now - timedelta(hours=24)
        daily_total = (
            db.query(func.sum(Transaction.amount))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "deposit",
                Transaction.status == "completed",
                Transaction.created_at >= day_ago,
            )
            .scalar()
            or Decimal("0")
        )
        if (daily_total + amount) >= DAILY_CUMULATIVE_THRESHOLD:
            result.add_flag(
                f"Cumulative 24h deposits: ${daily_total + amount} "
                f"(threshold: ${DAILY_CUMULATIVE_THRESHOLD})",
                risk="high",
            )

    # Rule 3: Rapid deposit-then-withdraw (structuring)
    if tx_type == "withdrawal":
        window = now - timedelta(minutes=RAPID_WITHDRAW_WINDOW_MINUTES)
        recent_deposits = (
            db.query(func.sum(Transaction.amount))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "deposit",
                Transaction.status == "completed",
                Transaction.created_at >= window,
            )
            .scalar()
            or Decimal("0")
        )
        if recent_deposits > 0 and amount >= recent_deposits * Decimal("0.8"):
            result.add_flag(
                f"Rapid deposit-withdraw: deposited ${recent_deposits} in last "
                f"{RAPID_WITHDRAW_WINDOW_MINUTES}min, now withdrawing ${amount}",
                risk="high",
            )
            result.block_transaction = True  # Hold for manual review

    # Rule 4: Smurfing detection (many small deposits)
    if tx_type == "deposit":
        smurf_window = now - timedelta(minutes=SMURFING_WINDOW_MINUTES)
        recent_count = (
            db.query(func.count(Transaction.id))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "deposit",
                Transaction.created_at >= smurf_window,
            )
            .scalar()
            or 0
        )
        if recent_count >= SMURFING_COUNT_THRESHOLD:
            result.add_flag(
                f"Potential structuring: {recent_count + 1} deposits in "
                f"{SMURFING_WINDOW_MINUTES} minutes",
                risk="high",
            )

    # Log flags to AML table if any were raised
    if result.flagged:
        _record_aml_flag(db, user_id, amount, tx_type, result, ip_address)

    return result


def _record_aml_flag(
    db: Session,
    user_id: int,
    amount: Decimal,
    tx_type: str,
    result: AMLScreeningResult,
    ip_address: Optional[str],
) -> None:
    """Persist AML flag for compliance review."""
    try:
        flag = AMLFlag(
            user_id=user_id,
            flag_type="transaction_screening",
            severity=result.risk_level,
            description="; ".join(result.flags),
            evidence={
                "amount": float(amount),
                "tx_type": tx_type,
                "risk_level": result.risk_level,
                "blocked": result.block_transaction,
                "ip_address": ip_address,
            },
            status="pending",
        )
        db.add(flag)
        db.flush()

        log_action(
            db,
            "aml_flag",
            user_id=user_id,
            resource_type="aml_flag",
            resource_id=flag.id,
            details={"flags": result.flags, "risk": result.risk_level},
        )
        logger.warning("AML flag raised for user %s: %s", user_id, result.flags)
    except Exception as e:
        logger.error("Failed to record AML flag: %s", e)
