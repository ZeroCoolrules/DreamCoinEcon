from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.user import User
from app.models.wallet import Wallet, Transaction
from app.models.game import GameRound
from app.core.security import get_current_user
from app.core.config import get_settings
from app.utils.audit import log_action
from datetime import datetime, timedelta
from typing import Optional, Tuple

BALANCE_TYPES = {
    "cash": "cash_balance",
    "bonus": "bonus_balance",
    "locked": "locked_balance",
    "withdrawable": "withdrawable_balance"
}

settings = get_settings()


def _lock_wallet(db: Session, user_id: int) -> Wallet:
    """
    C-4 FIX: Fetch and row-lock the wallet using SELECT ... FOR UPDATE.

    This prevents double-spend race conditions when two requests hit the
    same wallet concurrently. On SQLite (dev) the lock is a no-op because
    SQLite serialises writes at the database level; on PostgreSQL (prod)
    this acquires a real row lock that blocks concurrent transactions until
    the first one commits or rolls back.
    """
    is_sqlite = settings.DATABASE_URL.startswith("sqlite")

    query = db.query(Wallet).filter(Wallet.user_id == user_id)
    if not is_sqlite:
        query = query.with_for_update()

    wallet = query.first()
    if not wallet:
        wallet = Wallet(user_id=user_id)
        db.add(wallet)
        db.flush()  # flush to get the ID without committing
        if not is_sqlite:
            # Re-lock the freshly inserted row
            wallet = db.query(Wallet).filter(Wallet.id == wallet.id).with_for_update().first()
    return wallet


def get_or_create_wallet(db: Session, user_id: int) -> Wallet:
    """Non-locking wallet fetch — use for reads and display only."""
    wallet = db.query(Wallet).filter(Wallet.user_id == user_id).first()
    if not wallet:
        wallet = Wallet(user_id=user_id)
        db.add(wallet)
        db.commit()
        db.refresh(wallet)
    return wallet


def create_transaction(
    db: Session,
    wallet_id: int,
    user_id: int,
    tx_type: str,
    subtype: str,
    amount: Decimal,
    balance_before: Decimal,
    balance_after: Decimal,
    reference_id: Optional[str] = None,
    external_id: Optional[str] = None,
    description: Optional[str] = None,
    metadata: Optional[dict] = None,
    ip_address: Optional[str] = None,
    status: str = "completed"
) -> Transaction:
    tx = Transaction(
        wallet_id=wallet_id,
        user_id=user_id,
        type=tx_type,
        subtype=subtype,
        amount=amount,
        balance_before=balance_before,
        balance_after=balance_after,
        reference_id=reference_id,
        external_id=external_id,
        description=description,
        metadata=metadata,
        ip_address=ip_address,
        status=status
    )
    db.add(tx)
    db.flush()  # flush instead of commit — let the caller commit the full transaction
    return tx


def credit_balance(
    db: Session,
    user_id: int,
    amount: Decimal,
    balance_type: str = "cash",
    tx_type: str = "deposit",
    subtype: str = "",
    reference_id: Optional[str] = None,
    description: str = "",
    ip_address: Optional[str] = None
) -> Tuple[Wallet, Transaction]:
    wallet = _lock_wallet(db, user_id)
    attr = BALANCE_TYPES.get(balance_type, "cash_balance")
    before = getattr(wallet, attr)
    after = before + amount
    setattr(wallet, attr, after)

    if balance_type == "cash":
        wallet.withdrawable_balance += amount

    if tx_type == "deposit":
        wallet.total_deposited += amount
    if tx_type == "win":
        wallet.total_won += amount

    tx = create_transaction(
        db, wallet.id, user_id, tx_type, subtype, amount,
        before, after, reference_id=reference_id,
        description=description, ip_address=ip_address
    )
    db.commit()
    return wallet, tx


def debit_balance(
    db: Session,
    user_id: int,
    amount: Decimal,
    balance_type: str = "cash",
    tx_type: str = "withdrawal",
    subtype: str = "",
    reference_id: Optional[str] = None,
    description: str = "",
    ip_address: Optional[str] = None
) -> Tuple[Wallet, Transaction]:
    wallet = _lock_wallet(db, user_id)
    attr = BALANCE_TYPES.get(balance_type, "cash_balance")
    before = getattr(wallet, attr)

    if before < amount:
        raise ValueError("Insufficient balance")

    after = before - amount
    setattr(wallet, attr, after)

    if balance_type == "cash":
        wallet.withdrawable_balance -= amount

    if tx_type == "withdrawal":
        wallet.total_withdrawn += amount
    if tx_type == "bet":
        wallet.total_wagered += amount

    tx = create_transaction(
        db, wallet.id, user_id, tx_type, subtype, -amount,
        before, after, reference_id=reference_id,
        description=description, ip_address=ip_address
    )
    db.commit()
    return wallet, tx


def place_bet(
    db: Session,
    user_id: int,
    amount: Decimal,
    game_type: str,
    reference_id: Optional[str] = None,
    ip_address: Optional[str] = None
) -> Tuple[Wallet, Transaction]:
    # Enforce wager/loss limits BEFORE placing bet
    check_limits(db, user_id, amount)

    wallet = _lock_wallet(db, user_id)

    available = wallet.cash_balance + wallet.bonus_balance
    if available < amount:
        raise ValueError("Insufficient balance")

    # Use cash first, then bonus
    if wallet.cash_balance >= amount:
        return debit_balance(db, user_id, amount, "cash", "bet", f"game:{game_type}", reference_id, f"Bet on {game_type}", ip_address)
    else:
        cash_used = wallet.cash_balance
        bonus_used = amount - cash_used
        # Debit cash
        if cash_used > 0:
            debit_balance(db, user_id, cash_used, "cash", "bet", f"game:{game_type}", reference_id, f"Bet on {game_type} (cash)", ip_address)
        # Debit bonus
        return debit_balance(db, user_id, bonus_used, "bonus", "bet", f"game:{game_type}", reference_id, f"Bet on {game_type} (bonus)", ip_address)


def settle_bet(
    db: Session,
    user_id: int,
    amount: Decimal,
    game_type: str,
    reference_id: Optional[str] = None,
    ip_address: Optional[str] = None
) -> Tuple[Wallet, Transaction]:
    return credit_balance(db, user_id, amount, "cash", "win", f"game:{game_type}", reference_id, f"Win on {game_type}", ip_address)


def check_limits(db: Session, user_id: int, amount: Decimal) -> None:
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return

    now = datetime.utcnow()

    # Self-exclusion
    if user.self_excluded_until and user.self_excluded_until > now:
        raise ValueError("Account self-excluded")

    # Cooling off
    if user.cooling_off_until and user.cooling_off_until > now:
        raise ValueError("Account in cooling-off period")

    # Age verification
    if not user.age_verified:
        raise ValueError("Age verification required")

    # KYC for large amounts
    if amount > 1000 and user.kyc_status != "approved":
        raise ValueError("KYC required for deposits over $1000")

    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Daily deposit limit
    if user.deposit_limit_daily > 0:
        today_deposits = db.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == "deposit",
            Transaction.created_at >= today_start
        ).scalar() or 0
        if (today_deposits + amount) > user.deposit_limit_daily:
            raise ValueError("Daily deposit limit exceeded")

    # Daily Wager Limit
    if user.wager_limit_daily > 0:
        today_wagers = db.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == "bet",
            Transaction.created_at >= today_start
        ).scalar() or 0
        # bet amounts are recorded as negative, so take absolute value
        if abs(today_wagers) + amount > user.wager_limit_daily:
            raise ValueError("Daily wager limit exceeded")

    # Daily Loss Limit
    if user.loss_limit_daily > 0:
        today_wagers = abs(db.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == "bet",
            Transaction.created_at >= today_start
        ).scalar() or 0)

        today_wins = db.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == "win",
            Transaction.created_at >= today_start
        ).scalar() or 0

        net_loss = today_wagers - today_wins
        if net_loss + amount > user.loss_limit_daily:
            raise ValueError("Daily loss limit exceeded")
